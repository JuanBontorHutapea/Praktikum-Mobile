package com.example.tugas1praktpm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
